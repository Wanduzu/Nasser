<div id="success" class="step text-center">
    <h1 class="mb-2 fw-bolder">Success!</h1>
    <p class="mb-3">Application has been installed successfully!</p>
    <div class="mb-3">
        <label class="form-label mb-0">Email</label>
        <div class="text-dark fw-bold text-16">admin@admin.com</div>
    </div>
    <div class="mb-3">
        <label class="form-label mb-0">Password</label>
        <div class="text-dark fw-bold text-16">admin</div>
    </div>
    <a href="<?php echo '../login';?>" class="btn btn-primary next-btn btn-lg px-5 mx-auto">Admin Login</a>
</div>