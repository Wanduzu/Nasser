        <div id="welcome" class="step text-center">
            <h1 class="fw-bolder mb-2">Xtreaming Installation</h1>
            <p class="mb-4">
                Installation process is very easy and it takes less than 2 minutes!
            </p>

            <a href="<?php echo APP.'/install?step=2';?>" class="btn btn-success rounded-pill next-btn btn-lg px-5">Start Installation</a>
        </div>