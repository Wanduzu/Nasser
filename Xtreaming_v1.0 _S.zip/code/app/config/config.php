<?php 
require_once PATH.'/config/common.config.php'; // Common configuration
require_once PATH.'/config/db.config.php'; // Database configuration

// Path to temporary files directory
define("TEMP_PATH", ROOTPATH . "/public/upload/temp");


// Path to themes directory
define("THEME_PATH", ROOTPATH . "/inc/theme"); 